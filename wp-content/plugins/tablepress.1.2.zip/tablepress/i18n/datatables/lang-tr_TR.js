{
	"sProcessing":	 "İşleniyor...",
	"sLengthMenu":	 "Sayfada _MENU_ Kayıt Göster",
	"sZeroRecords":	 "Eşleşen Kayıt Bulunmadı",
	"sInfo":		 "_TOTAL_ Kayıttan _START_ - _END_ Arası Kayıtlar",
	"sInfoEmpty":	 "Kayıt Yok",
	"sInfoFiltered": "(_MAX_ Kayıt İçerisinden Bulunan)",
	"sInfoPostFix":	 "",
	"sSearch":		 "Bul:",
	"oPaginate": {
		"sFirst":	 "İlk",
		"sPrevious": "Önceki",
		"sNext":	 "Sonraki",
		"sLast":	 "Son"
	}
}