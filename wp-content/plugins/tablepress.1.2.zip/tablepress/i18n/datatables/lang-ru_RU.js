{
	"sProcessing":	 "Подождите...",
	"sLengthMenu":	 "Показать _MENU_ записей",
	"sZeroRecords":	 "Записи отсутствуют.",
	"sInfo":		 "Показаны записи с _START_ по _END_ из _TOTAL_ записей",
	"sInfoEmpty":	 "Выбрано записи с 0 по 0 из 0 записей",
	"sInfoFiltered": "(выбрано из _MAX_ записей)",
	"sInfoPostFix":	 "",
	"sSearch":		 "Найти:",
	"oPaginate": {
		"sFirst": "Первая",
		"sPrevious": "Предыдущая",
		"sNext": "Следующая",
		"sLast": "Последняя"
	}
}